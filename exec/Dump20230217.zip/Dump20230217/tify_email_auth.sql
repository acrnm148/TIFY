-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8e208.p.ssafy.io    Database: tify
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `email_auth`
--

DROP TABLE IF EXISTS `email_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_auth` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `auth_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `expire_date` datetime(6) DEFAULT NULL,
  `expired` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_auth`
--

LOCK TABLES `email_auth` WRITE;
/*!40000 ALTER TABLE `email_auth` DISABLE KEYS */;
INSERT INTO `email_auth` VALUES (1,'5ba3b1b0-3574-49ef-82f8-77bc0180d440','a0511a@naver.com','2023-02-09 15:17:07.012000',_binary ''),(2,'6ab50ebd-03d5-4dc3-a4f5-fafb2b4fc4c1','acrnm148@gmail.com','2023-02-09 15:20:29.358000',_binary ''),(3,'3219f649-e2af-4650-b1e8-c179c7cbf776','a0511a25@gmail.com','2023-02-09 15:22:50.943000',_binary ''),(4,'8bc14ac6-5038-4395-a8b3-1d05ef292780','a0511a25@gmail.com','2023-02-09 15:23:40.025000',_binary '\0'),(5,'f24fae94-5504-41d2-85e1-49ddbd5e16b6','kihan@test.com','2023-02-09 15:26:49.860000',_binary '\0'),(6,'52801afb-a29b-413b-8a09-89dc789bf69f','a0511a25@gmail.com','2023-02-09 15:26:52.267000',_binary ''),(7,'0359f606-e08d-4ef9-b496-cae359fd8e8c','pos04118@naver.com','2023-02-09 15:29:27.661000',_binary ''),(8,'51336edf-612d-47a1-a4a5-16cdc8bc389f','octover1025@naver.com','2023-02-09 15:30:42.489000',_binary ''),(9,'50544409-0a20-40cc-a154-b34c33a4d36f','rkdrlgks321@naver.com','2023-02-11 17:37:13.108000',_binary ''),(10,'66e947bb-d84f-48b5-a519-187eafd50445','pos04118@naver.com','2023-02-12 00:11:32.531000',_binary ''),(11,'8757b794-7f2a-44e6-aa71-ceca7abdd900','rkdrlgks321@gmail.com','2023-02-13 00:38:41.549000',_binary ''),(12,'420ba236-3f47-4b49-8b5b-46d8ef1a0970','rkdrlgks321@naver.com','2023-02-13 13:24:23.665000',_binary ''),(13,'54f7693d-5a42-4897-aee5-ae9236518e92','rkdrlgks321@naver.com','2023-02-13 13:48:30.362000',_binary '\0'),(14,'4a34adb5-297a-412e-9da6-4b098b12c9e4','rkdrlgks321@naver.com','2023-02-13 13:55:39.957000',_binary '\0'),(15,'eca8d8ed-1ca3-4a85-950f-f28452b1a1db','pos04118@gmail.com','2023-02-14 06:10:02.924000',_binary ''),(16,'2f976880-07e2-4322-87b2-fc035c9ee995','rkdrlgks321@naver.com','2023-02-14 08:51:26.760000',_binary ''),(17,'2e9e0c28-2658-4c50-b0a2-98a59a6e6819','rkdrlgks321@gmail.com','2023-02-14 10:48:54.535000',_binary ''),(18,'72481c17-a507-4c08-8b9d-5c5965a4cfd9','kmj5052@gmail.com','2023-02-14 15:29:33.538000',_binary ''),(19,'c3fcd3e3-c547-44df-acc3-f7f170205ec1','kmj5052@gmail.com','2023-02-14 16:02:01.567000',_binary ''),(20,'1c735dc7-a6d0-4148-8b14-26fa16cc4bce','pos04118@gmail.com','2023-02-15 11:14:32.167000',_binary ''),(21,'1b787579-5bb4-4f2d-a513-ed71c211708c','duddlf1025@naver.com','2023-02-15 14:59:25.283000',_binary '\0'),(22,'f6177636-a4e1-4f4e-92a3-25a9c6a1576d','duddlf1025@gmail.com','2023-02-15 15:00:03.405000',_binary ''),(23,'61642eb7-ff6f-4b65-8dbc-bf2767181849','test@test.com','2023-02-16 10:04:13.957000',_binary '\0'),(24,'40939757-ac55-416d-905b-4c2c5d52f3f2','duddlf1025@gmail.com','2023-02-16 10:12:41.940000',_binary ''),(25,'668643c3-517f-434d-9938-731d6b674a95','seunghan4769@naver.com','2023-02-16 16:51:50.893000',_binary ''),(26,'e51ec345-53f6-4022-9801-d63f07e8cdd9','duddlf1025@gmail.com','2023-02-17 09:59:52.826000',_binary '');
/*!40000 ALTER TABLE `email_auth` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:44:22
