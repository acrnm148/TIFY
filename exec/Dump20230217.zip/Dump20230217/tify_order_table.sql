-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8e208.p.ssafy.io    Database: tify
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_table`
--

DROP TABLE IF EXISTS `order_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_table` (
  `order_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` varchar(255) DEFAULT NULL,
  `delivery_number` varchar(255) DEFAULT NULL,
  `gathered_price` int NOT NULL,
  `order_price` int NOT NULL,
  `state` int NOT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `gift_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `modified_date` datetime(6) DEFAULT NULL,
  `created_dt` varchar(255) DEFAULT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `wish_id` bigint DEFAULT NULL,
  `wish_name` varchar(255) DEFAULT NULL,
  `gift_name` varchar(255) DEFAULT NULL,
  `pure_price` int DEFAULT NULL,
  `gift_gift_id` bigint DEFAULT NULL,
  `gift_img_url` varchar(255) DEFAULT NULL,
  `wish_finish_date` varchar(255) DEFAULT NULL,
  `id` bigint DEFAULT NULL,
  `user_option` varchar(255) DEFAULT NULL,
  `ref_state` varchar(255) DEFAULT NULL,
  `ref_user_account` varchar(255) DEFAULT NULL,
  `ref_user_bank` varchar(255) DEFAULT NULL,
  `ref_user_name` varchar(255) DEFAULT NULL,
  `gift_product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `FKnmdjo6oaf01ow2reubtrhl6ev` (`user_id`),
  KEY `FKdywn6o9aee2ry6vrs0eu441ss` (`id`),
  KEY `FK7sjy1v1b6s5gptlaas79p5rea` (`gift_id`),
  KEY `FKg1ctvui5bunxwburai93yev8m` (`gift_gift_id`),
  CONSTRAINT `FK7sjy1v1b6s5gptlaas79p5rea` FOREIGN KEY (`gift_id`) REFERENCES `gift` (`gift_id`),
  CONSTRAINT `FKdywn6o9aee2ry6vrs0eu441ss` FOREIGN KEY (`id`) REFERENCES `gift` (`gift_id`),
  CONSTRAINT `FKg1ctvui5bunxwburai93yev8m` FOREIGN KEY (`gift_gift_id`) REFERENCES `gift` (`gift_id`),
  CONSTRAINT `FKnmdjo6oaf01ow2reubtrhl6ev` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1020 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_table`
--

LOCK TABLES `order_table` WRITE;
/*!40000 ALTER TABLE `order_table` DISABLE KEYS */;
INSERT INTO `order_table` VALUES (10,NULL,'568727556622',6000000,5250000,1,'010-7367-3317',15,2,NULL,'2023.2.10','2023-02-10 13:55:34.775000',10000,'웃으면 복이와요','왈라비',0,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/b9741b41-63d3-46ef-a5a3-a58a6c9d7be2.png','2023-03-22',NULL,NULL,'Y','','','',NULL),(100,NULL,'568727556622',3150000,3150000,1,'010-6265-0288',100000,9,NULL,'2023.2.10','2023-02-10 14:31:31.719000',10000,'네이버 취업했습니다!!','붉은왈라루',0,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/4f05547e-1e04-4d18-a486-4424b58e1374.jpg','2023-02-12',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(101,NULL,NULL,3150000,3150000,1,'010-7367-3317',100008,5,NULL,'2023.2.11','2023-02-11 14:38:31.365000',10003,'축하부탁드림','붉은왈라루',0,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/d9daaf20-2301-4b51-a017-d7b7b89455f6.jpg','2023-02-22',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(102,NULL,NULL,9000088,3150000,1,'010-6265-0288',100001,9,NULL,'2023.2.13','2023-02-13 10:06:49.711000',10000,'네이버 취업했습니다!!','붉은왈라루',NULL,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/d9daaf20-2301-4b51-a017-d7b7b89455f6.jpg','2023-02-12',NULL,'요리사-1500',NULL,NULL,NULL,NULL,NULL),(103,NULL,NULL,9000000,3150000,1,'010-6265-0288',100002,9,NULL,'2023.2.13','2023-02-13 10:06:55.580000',10000,'네이버 취업했습니다!!','붉은왈라루',NULL,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/d9daaf20-2301-4b51-a017-d7b7b89455f6.jpg','2023-02-12',NULL,'요리사-1500',NULL,NULL,NULL,NULL,NULL),(104,NULL,NULL,9000000,3150000,1,'010-6265-0288',100003,9,NULL,'2023.2.13','2023-02-13 10:07:00.164000',10000,'네이버 취업했습니다!!','붉은왈라루',NULL,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/d9daaf20-2301-4b51-a017-d7b7b89455f6.jpg','2023-02-12',NULL,'요리사-1500',NULL,NULL,NULL,NULL,NULL),(105,NULL,NULL,9000000,3150000,1,'010-6265-0288',100004,9,NULL,'2023.2.13','2023-02-13 10:07:04.340000',10000,'네이버 취업했습니다!!','붉은왈라루',NULL,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/d9daaf20-2301-4b51-a017-d7b7b89455f6.jpg','2023-02-12',NULL,'요리사-1500',NULL,NULL,NULL,NULL,NULL),(106,NULL,NULL,9000000,3150000,1,'010-6265-0288',100005,9,NULL,'2023.2.13','2023-02-13 10:07:08.656000',10000,'네이버 취업했습니다!!','붉은왈라루',NULL,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/d9daaf20-2301-4b51-a017-d7b7b89455f6.jpg','2023-02-12',NULL,'요리사-1500',NULL,NULL,NULL,NULL,NULL),(107,NULL,NULL,9000000,3150000,1,'010-6265-0288',100006,9,NULL,'2023.2.13','2023-02-13 10:07:13.409000',10001,'첫째 아들이 세상에 나왔어요!','붉은왈라루',NULL,NULL,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/d9daaf20-2301-4b51-a017-d7b7b89455f6.jpg','2023-02-18',NULL,'직업-[object Object]',NULL,NULL,NULL,NULL,NULL),(1005,NULL,NULL,29205,19205,0,'010-7367-3317',100021,11,NULL,'2023.2.13','2023-02-13 12:07:10.953000',10014,'축하부탁드림','곰곰 냉동 블루베리',NULL,100021,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-03-21',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1006,NULL,NULL,25000,19205,0,'010-7367-3317',100020,11,NULL,'2023.2.13','2023-02-14 07:23:22.478000',10014,'축하부탁드림','곰곰 냉동 블루베리',NULL,100020,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-03-21',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1007,NULL,NULL,20000,19205,0,'010-7367-3317',100022,11,NULL,'2023.2.13','2023-02-14 07:25:44.502000',10014,'축하부탁드림','곰곰 냉동 블루베리',NULL,100022,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-03-21',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1008,NULL,NULL,20000,19205,0,'010-7367-3317',100023,11,NULL,'2023.2.13','2023-02-14 07:28:48.438000',10014,'축하부탁드림','곰곰 냉동 블루베리',NULL,100023,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-03-21',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1009,NULL,NULL,20000,19205,0,'010-7367-3317',100024,11,NULL,'2023.2.13','2023-02-14 07:30:49.581000',10014,'축하부탁드림','곰곰 냉동 블루베리',NULL,100024,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-03-21',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1010,NULL,NULL,20000,19205,0,'010-7367-3317',100025,11,NULL,'2023.2.13','2023-02-14 07:32:24.253000',10014,'축하부탁드림','곰곰 냉동 블루베리',NULL,100025,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-03-21',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1011,NULL,NULL,19205,19205,0,'010-1111-1111',100040,20,NULL,'2023.2.14','2023-02-14 22:01:30.568000',10024,'qwe','곰곰 냉동 블루베리',NULL,100040,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-02-18',NULL,'중량 × 수량-undefined',NULL,NULL,NULL,NULL,1027),(1012,NULL,NULL,20000,18795,0,'010-1515-1515',100036,17,NULL,'2023.2.14','2023-02-15 01:17:51.364000',10021,'test','명실상주 GAP 인증 해발 300 상주곶감 (냉동)',NULL,100036,'//image6.coupangcdn.com/image/retail/images/2020/12/10/20/8/d5153a96-8c63-4ca6-adcc-f6f3037a9e21.jpg','2023-02-17',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1015),(1013,NULL,NULL,20000,19205,0,'010-7367-3317',100035,11,NULL,'2023.2.14','2023-02-15 02:43:44.617000',10020,'test','곰곰 냉동 블루베리',NULL,100035,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-02-23',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1014,NULL,NULL,20000,19205,0,'010-7367-3317',100029,11,NULL,'2023.2.14','2023-02-15 02:51:02.851000',10017,'축하부탁드림','곰곰 냉동 블루베리',NULL,100029,'//image6.coupangcdn.com/image/retail/images/361831759417319-1481f4a1-5fa0-4df8-a1b4-990f10b1d4d3.jpg','2023-02-24',NULL,'중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1027),(1015,NULL,NULL,1144500,1144500,0,'010-2392-2930',100052,22,NULL,'2023.2.15','2023-02-15 11:22:40.874000',10040,'21번째 생일이에요','AU테크 스카닉 F20 접이식 팻바이크 전기자전거 36V 7.5Ah',NULL,100052,'//image9.coupangcdn.com/image/vendor_inventory/bded/54f02990e01af3d51d30963168f8a4fa2e48dc1a7668bf29535a9e88454c.jpg','2023-02-18',NULL,'-null',NULL,NULL,NULL,NULL,1188),(1016,NULL,NULL,5265000,5250000,0,'010-2487-1660',100037,1,NULL,'2023.2.15','2023-02-15 15:35:07.108000',10022,'야인시대','왈라비',NULL,100037,'https://tifyimage.s3.ap-northeast-2.amazonaws.com/b9741b41-63d3-46ef-a5a3-a58a6c9d7be2.png','2023-02-14',NULL,'-[object Object]',NULL,NULL,NULL,NULL,2),(1017,NULL,NULL,19740,19740,0,'010-2487-1660',100038,1,NULL,'2023.2.15','2023-02-15 15:37:34.088000',10022,'야인시대','딜리조이 맥반석 구운란',NULL,100038,'//image9.coupangcdn.com/image/retail/images/1839760104320376-1f7c9219-9a2c-410d-a55f-5e34776762bb.jpg','2023-02-14',NULL,'개당 중량 × 수량-[object Object]',NULL,NULL,NULL,NULL,1021),(1018,NULL,NULL,24381,24381,0,'010-2487-1660',100045,1,NULL,'2023.2.15','2023-02-15 16:40:25.689000',10036,'잠온다','오뚜기 컵누들 매콤한맛 37.8g',NULL,100045,'//image9.coupangcdn.com/image/retail/images/7390496313642340-85d70a52-4106-479c-a96d-ff0d3fc58b03.jpg','2023-02-17',NULL,'총 수량-[object Object]',NULL,NULL,NULL,NULL,1022),(1019,NULL,NULL,46200,0,0,'010-2487-1660',100046,1,NULL,'2023.2.15','2023-02-15 16:41:33.636000',10036,'잠온다','트루리빙 토스터기',NULL,100046,'//thumbnail7.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/3048690922333-cfe728bd-aaf6-4c98-8387-b40b3f844f92.jpg','2023-02-17',NULL,'',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `order_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:44:18
