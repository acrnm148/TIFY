-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8e208.p.ssafy.io    Database: tify
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `addr1` varchar(255) DEFAULT NULL,
  `addr2` varchar(255) DEFAULT NULL,
  `birth` varchar(255) DEFAULT NULL,
  `birth_year` varchar(255) DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_auth` bit(1) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_img` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `roles` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `refresh_token_id` bigint DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `FK44acn4a65scossvecwa6jx3wt` (`refresh_token_id`),
  CONSTRAINT `FK44acn4a65scossvecwa6jx3wt` FOREIGN KEY (`refresh_token_id`) REFERENCES `refresh_token` (`refresh_token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'부산 강서구 낙동남로 369','22','0511','1993','2023-02-09 15:13:13.159000','a0511a@naver.com',_binary '',NULL,'왈','$2a$10$rG24yvPDqLudHW0o2eeEKe0O8YTdajuxpKC2g3Ce0AZzAnFoT.UoK','https://tifyimage.s3.ap-northeast-2.amazonaws.com/KakaoTalk_20230213_121022661.jpg',NULL,'USER','01024871660','a0511a@naver.com','이상훈','46728',510),(2,'부산시 해운대구','104동 402호','0923','1999','2023-02-09 15:16:59.141000','acrnm148@gmail.com',_binary '','F','수나캉','$2a$10$DQvapkbC8NCRnFct6qaSpuF/5OwptVtmR6LkeZF89rHf4ZOAKRB.a','https://tifyimage.s3.ap-northeast-2.amazonaws.com/9bd3f9f9-ff32-4e97-889e-57cf47cfb1e8.png',NULL,'USER','01062650289','acrnm148@gmail.com','강수나','123456',504),(4,'','','0511','1993','2023-02-09 15:22:46.705000','a0511a25@gmail.com',_binary '',NULL,'이상훈아닌데요','$2a$10$f2oU40xSHoYm6Ic7YeRj1.rWZPxX1NTwshXpySGViyzFTktOdPb2y','https://tifyimage.s3.ap-northeast-2.amazonaws.com/KakaoTalk_20230213_121022661.jpg',NULL,'USER','01024871660','a0511a25@gmail.com','이상훈',NULL,NULL),(5,'경기 용인시 기흥구 용구대로 1842','집에보내줘','1215','1997','2023-02-09 15:25:46.371000','pos041@naver.com',_binary '',NULL,'지렁이','123','https://tifyimage.s3.ap-northeast-2.amazonaws.com/97d26c1c-20a7-42ea-95f7-6869552c4a25.jpg',NULL,'USER','01073673317','pos041@naver.com','김몌지','17080',127),(6,'','','1025','1996','2023-02-09 15:26:50.435000','octover1024@naver.com',_binary '',NULL,'왈라비one','$2a$10$VKmKXGEs0iRA5AAn2oKgLeeXxj9QD5d8hDrwea7GbHeMmgwQW8iLm','https://tifyimage.s3.ap-northeast-2.amazonaws.com/a8333f71-8740-4cfa-8339-748346341ce8.jpg',NULL,'USER','01099999999','octover1024@naver.com','고영일',NULL,NULL),(7,'부산시 해운대구','104동 402호','0923','1999','2023-02-09 15:32:05.444000','octover1023@naver.com',_binary '','F','왈라비two','$2a$10$ybbPZyvd2DGR4E0nXwkxUus2Z2YlCBuvzx0RO7T6KmYIivzbH5jMO','https://tifyimage.s3.ap-northeast-2.amazonaws.com/11cbbf5e-36f9-4983-a50f-afe045a5c047.png',NULL,'USER','01062650288','octover1023@naver.com','고영일','123456',NULL),(8,'부산시 해운대구','104동 402호','0923','1999','2023-02-09 15:34:23.271000','octover1022@naver.com',_binary '','F','왈라비three','$2a$10$e7SFYlxlOO.En9a7SL6xseHhlVFjIt/fITgTvr1h0jqxrk3KnVe3q','https://tifyimage.s3.ap-northeast-2.amazonaws.com/7065d982-40fd-4bbb-b547-7c87152af729.png',NULL,'USER','01062650288','octover1022@naver.com','고영삼','123456',NULL),(9,'부산시 해운대구','104동 402호','0923','1999','2023-02-09 15:35:43.839000','octover1025@naver.com',_binary '','F','왈라비','$2a$10$235nN3RjXuuEfMJeDUP/HO3ePoH39r0boypB1ekHEGMvRNOzFGqx6','https://tifyimage.s3.ap-northeast-2.amazonaws.com/e1118c5a-34c8-40dd-a411-5e3ad972f7cd.jpg',NULL,'USER','01062650288','octover1025@naver.com','강수나','123456',506),(11,'경기 용인시 기흥구 용구대로 1842','올올올','1215','1997','2023-02-12 00:10:47.569000','pos04118@naver.com',_binary '',NULL,'몌지렁지','$2a$10$aWybf5bJgWhSktGnfWoihOKOc.mDbyyV5vraMmn0LDcQOAkdNz/ti','https://tifyimage.s3.ap-northeast-2.amazonaws.com/985c5b8c-9660-44c9-af51-718172f7ba56.jpg',NULL,'USER','01073673317','pos04118@naver.com','김몌지','17080',511),(12,NULL,NULL,NULL,NULL,'2023-02-12 20:09:09.294000','h5282000@naver.com',NULL,NULL,'한진성',NULL,'http://k.kakaocdn.net/dn/cwHHM5/btrXUXlbpSV/ujGIZLQfRsguSDvAk0BEoK/img_640x640.jpg','Kakao','USER',NULL,'2649240737',NULL,NULL,155),(15,NULL,NULL,NULL,NULL,'2023-02-13 05:30:39.678000','ssookkookk@naver.com',NULL,NULL,'강수나',NULL,'http://k.kakaocdn.net/dn/hcjw0/btrSRR4QJqC/yF1Zis9FwDa9PkCqeVloG1/img_640x640.jpg','Kakao','USER',NULL,'2543509554',NULL,NULL,167),(17,'','','1215','1997','2023-02-14 06:07:00.408000','pos@gmail.com',_binary '',NULL,'몌','$2a$10$xO2wdIq45Oh8zpUIu2mpme2OU4iuIr6De0R0AyozpDsWk2WJh8SuW','https://tifyimage.s3.ap-northeast-2.amazonaws.com/9bdacdc5-1d68-4094-85ea-b203caf4300e.jpg',NULL,'USER','01015151515','asd','김',NULL,NULL),(18,'부산 사상구 괘법동 270-1','','1118','1997','2023-02-14 08:47:15.414000','rkdrlgks321@naver.com',_binary '','남여','rkdrlgks','$2a$10$tdfrs0VNaVsalLZzFTN45O070r9Mn/TcVzDrxsSWWSeRTwmKjxiCW','https://tifyimage.s3.ap-northeast-2.amazonaws.com/5e1dc3dc-12c3-4363-8e91-8676c44f122b.png',NULL,'ADMIN','010-4922-1157','rkdrlgks321@naver.com','강기한','46964',490),(19,'','','1118','1997','2023-02-14 13:42:40.379000','rkdrlgks321@gmail.com',_binary '',NULL,'rr','$2a$10$AkyXgLEqKCjO6178PoewqO1oN9ORVBTCwIkmZ.loBq3SzObVDqoGG','https://tifyimage.s3.ap-northeast-2.amazonaws.com/5e1dc3dc-12c3-4363-8e91-8676c44f122b.png',NULL,'USER','01049221157','rkdrlgks321@gmail.com','r',NULL,251),(20,'서울 송파구 백제고분로 2','qweqwe','0101','1999','2023-02-14 15:57:36.863000','kmj5052@gmail.com',_binary '',NULL,'강코치','$2a$10$aR8lbNiqTahWT5muwYwsGuxF9TAD2X1tLkzO82hAmWThvNtqWneqW','https://tifyimage.s3.ap-northeast-2.amazonaws.com/5e1dc3dc-12c3-4363-8e91-8676c44f122b.png',NULL,'USER','01011111111','kmj5052@gmail.com','강코치','05500',264),(22,'','','1024','1995','2023-02-15 11:11:02.370000','pos04118@gmail.com',_binary '',NULL,'김상훈','$2a$10$5IRMIdGNaeCG7OepQ/7sCe/6HBLqe4qSKh9nTrVkcTpBEVnsT0DeK','https://tifyimage.s3.ap-northeast-2.amazonaws.com/c8b556ea-38e2-4635-b803-f553f120f4f8.png',NULL,'USER','01023922930','pos04118@gmail.com','고영일',NULL,NULL),(26,NULL,NULL,NULL,NULL,'2023-02-15 14:16:27.170000','octover1025@naver.com',NULL,NULL,'Do',NULL,'https://ssl.pstatic.net/static/pwe/address/img_profile.png','Naver','USER',NULL,'4VHEyNR7pJHB7f1M_1TojlFI-akuUiX1dwHyIsIA0IE',NULL,NULL,NULL),(27,NULL,NULL,NULL,NULL,'2023-02-15 14:17:55.569000','ssookkookk@naver.com',NULL,NULL,'suna',NULL,'https://phinf.pstatic.net/contact/20221122_194/1669127321231YRfQL_JPEG/%B1%B8%B1%B3%C8%AF.jpg','Naver','USER',NULL,'-7BP8BmPyXxFYVce_5yymME1r7jstS-TFbgUhcADdcQ',NULL,NULL,344),(29,NULL,NULL,NULL,NULL,'2023-02-15 14:51:10.718000','duddlf1025@gmail.com',NULL,NULL,'고영일',NULL,'http://k.kakaocdn.net/dn/cgxEEA/btrWQLsZV7k/WEBQitfxIEKUPVHir3xuQ0/img_640x640.jpg','Kakao','USER',NULL,'2643489004',NULL,NULL,NULL),(30,'부산 해운대구 반송로 648-1','123','1022','1999','2023-02-15 15:46:12.811000','duddlf1025@gmail.com',_binary '',NULL,'강코치코치치','$2a$10$yFyTiNn4rJfCI9xiwErrM.wanl01vN7Y6iQifLt3qpst72KJDRlqi','https://tifyimage.s3.ap-northeast-2.amazonaws.com/5e1dc3dc-12c3-4363-8e91-8676c44f122b.png',NULL,'USER','01020312931','duddlf1024@gmail.com','고영일','48003',NULL),(31,'','','1025','1996','2023-02-16 10:40:45.536000','!duddlf1025@gmail.com',_binary '',NULL,'테스트맨','$2a$10$guHAE5itmJnROrlqF/3ELOd58CibmcrXq10qZsepU8l4Sii3//IQK','https://tifyimage.s3.ap-northeast-2.amazonaws.com/5e1dc3dc-12c3-4363-8e91-8676c44f122b.png',NULL,'USER','010-2031-2031','!duddlf1025@gmail.com','테스트',NULL,NULL),(32,'','','0310','1997','2023-02-16 16:47:39.965000','seunghan4769@naver.com',_binary '',NULL,'승한이오','$2a$10$ztbVeKxdev556CtFdhVkCuKKJRndnNZ.XIMXMuwlo/yKjfFGahvYC','https://tifyimage.s3.ap-northeast-2.amazonaws.com/5e1dc3dc-12c3-4363-8e91-8676c44f122b.png',NULL,'USER','010-5050-4769','seunghan4769@naver.com','이승한',NULL,438),(33,'','','0412','1998','2023-02-17 10:10:52.076000','duddlf1025@gmail.com',_binary '',NULL,'빵좋아','$2a$10$yfBSCaHXvIVpBe/LeeVsq.iscZUQYCKLptUqufGDmypqYf..NP0Xu','https://tifyimage.s3.ap-northeast-2.amazonaws.com/a3eabc34-c848-4c1b-aff1-3efe9a672b4c.jpg',NULL,'USER','010-8888-8888','duddlf1025@gmail.com','강순아',NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:44:19
